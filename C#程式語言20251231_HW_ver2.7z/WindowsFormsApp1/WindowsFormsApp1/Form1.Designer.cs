﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.btnUlongMaxPrime_Click = new System.Windows.Forms.Button();
            this.txtInputNum = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtInputNumIsPrime = new System.Windows.Forms.TextBox();
            this.btnNumIsPrime = new System.Windows.Forms.Button();
            this.txtShowPrime = new System.Windows.Forms.TextBox();
            this.btnListPrime = new System.Windows.Forms.Button();
            this.txtUlongMaxPrime = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnUlongMaxPrime_Click
            // 
            this.btnUlongMaxPrime_Click.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnUlongMaxPrime_Click.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnUlongMaxPrime_Click.Location = new System.Drawing.Point(13, 13);
            this.btnUlongMaxPrime_Click.Margin = new System.Windows.Forms.Padding(4);
            this.btnUlongMaxPrime_Click.Name = "btnUlongMaxPrime_Click";
            this.btnUlongMaxPrime_Click.Size = new System.Drawing.Size(271, 39);
            this.btnUlongMaxPrime_Click.TabIndex = 0;
            this.btnUlongMaxPrime_Click.Text = "求得ulong的最大質數";
            this.btnUlongMaxPrime_Click.UseVisualStyleBackColor = false;
            this.btnUlongMaxPrime_Click.Click += new System.EventHandler(this.btnUlongMaxPrime_Click_Click);
            // 
            // txtInputNum
            // 
            this.txtInputNum.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtInputNum.Location = new System.Drawing.Point(0, 39);
            this.txtInputNum.Name = "txtInputNum";
            this.txtInputNum.Size = new System.Drawing.Size(466, 39);
            this.txtInputNum.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.label1.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label1.Location = new System.Drawing.Point(6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(460, 31);
            this.label1.TabIndex = 3;
            this.label1.Text = "輸入任一個ulong 的參數, 判斷是否是質數";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtInputNumIsPrime);
            this.groupBox1.Controls.Add(this.btnNumIsPrime);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtInputNum);
            this.groupBox1.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox1.Location = new System.Drawing.Point(13, 69);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(921, 84);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            // 
            // txtInputNumIsPrime
            // 
            this.txtInputNumIsPrime.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.txtInputNumIsPrime.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtInputNumIsPrime.Location = new System.Drawing.Point(653, 39);
            this.txtInputNumIsPrime.Name = "txtInputNumIsPrime";
            this.txtInputNumIsPrime.Size = new System.Drawing.Size(144, 39);
            this.txtInputNumIsPrime.TabIndex = 5;
            this.txtInputNumIsPrime.Text = "是/不是 質數";
            // 
            // btnNumIsPrime
            // 
            this.btnNumIsPrime.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnNumIsPrime.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnNumIsPrime.Location = new System.Drawing.Point(496, 39);
            this.btnNumIsPrime.Margin = new System.Windows.Forms.Padding(4);
            this.btnNumIsPrime.Name = "btnNumIsPrime";
            this.btnNumIsPrime.Size = new System.Drawing.Size(127, 39);
            this.btnNumIsPrime.TabIndex = 4;
            this.btnNumIsPrime.Text = "判斷";
            this.btnNumIsPrime.UseVisualStyleBackColor = false;
            this.btnNumIsPrime.Click += new System.EventHandler(this.btnNumIsPrime_Click);
            // 
            // txtShowPrime
            // 
            this.txtShowPrime.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txtShowPrime.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtShowPrime.Location = new System.Drawing.Point(13, 206);
            this.txtShowPrime.Multiline = true;
            this.txtShowPrime.Name = "txtShowPrime";
            this.txtShowPrime.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtShowPrime.Size = new System.Drawing.Size(921, 406);
            this.txtShowPrime.TabIndex = 5;
            // 
            // btnListPrime
            // 
            this.btnListPrime.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnListPrime.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnListPrime.Location = new System.Drawing.Point(13, 160);
            this.btnListPrime.Margin = new System.Windows.Forms.Padding(4);
            this.btnListPrime.Name = "btnListPrime";
            this.btnListPrime.Size = new System.Drawing.Size(328, 39);
            this.btnListPrime.TabIndex = 6;
            this.btnListPrime.Text = "從2開始增加, 不斷列出質數";
            this.btnListPrime.UseVisualStyleBackColor = false;
            this.btnListPrime.Click += new System.EventHandler(this.btnListPrime_Click);
            // 
            // txtUlongMaxPrime
            // 
            this.txtUlongMaxPrime.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.txtUlongMaxPrime.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.txtUlongMaxPrime.Location = new System.Drawing.Point(324, 14);
            this.txtUlongMaxPrime.Multiline = true;
            this.txtUlongMaxPrime.Name = "txtUlongMaxPrime";
            this.txtUlongMaxPrime.ReadOnly = true;
            this.txtUlongMaxPrime.Size = new System.Drawing.Size(472, 38);
            this.txtUlongMaxPrime.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(939, 642);
            this.Controls.Add(this.txtUlongMaxPrime);
            this.Controls.Add(this.btnListPrime);
            this.Controls.Add(this.txtShowPrime);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnUlongMaxPrime_Click);
            this.Font = new System.Drawing.Font("微軟正黑體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUlongMaxPrime_Click;
        private System.Windows.Forms.TextBox txtInputNum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtShowPrime;
        private System.Windows.Forms.Button btnNumIsPrime;
        private System.Windows.Forms.Button btnListPrime;
        private System.Windows.Forms.TextBox txtInputNumIsPrime;
        private System.Windows.Forms.TextBox txtUlongMaxPrime;
    }
}

