﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Numerics;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        ulong UlongMaxPrimeNum = 18446744073709551557;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //直接在屬性更改就行
            //txtUlongMaxPrime.ReadOnly = true;   //表示不允許修改，只能對文字做選取、捲動和顯示的功能，相當於 Label。

        }
        ulong UlongMaxPrime(ulong num)
        {
            //   return UlongMaxPrimeNum;    //目前找不到辦法直接顯示


            Console.WriteLine($"in function");
            for (ulong i = num; i >= 2; i--)
            {
                Console.WriteLine(i);
                /*
                if (i % 2 == 0)
                    continue;
                */
                /*
                if(NumIsPrime(i))
                {
                    Console.WriteLine($"find {i}");
                    return i;
                }
                */
                if (ChatGPT2IsPrime(i))
                {
                    Console.WriteLine($"find {i}");
                    return i;
                }
                Console.WriteLine($"run");
            }
            return 0;
        }
        private void btnUlongMaxPrime_Click_Click(object sender, EventArgs e)
        {
            ulong num = ulong.MaxValue;
            ulong max_prime_num = UlongMaxPrime(num);   //18446744073709551557
            txtUlongMaxPrime.Text = $"{max_prime_num}";
        }

        private void btnNumIsPrime_Click(object sender, EventArgs e)
        {
            try
            {
                ulong num = Convert.ToUInt64(txtInputNum.Text);
                if (ChatGPT3IsPrime_test(num))
                {
                    txtInputNumIsPrime.Text = $"是質數";
                }
                else
                {
                    txtInputNumIsPrime.Text = $"不是質數";
                }
            }
            catch
            {
                MessageBox.Show("請輸入數字");
            }
        }

        void ListPrime()
        {
            Stopwatch sw = new Stopwatch();
            txtShowPrime.Text = $"以下為結果\r\n-----------------\r\n";
            ulong num = ulong.MaxValue;
            int count = -1; //初始值
            for (ulong i = 2; i < num; i++)
            {
                //    Console.WriteLine($"{i} run");
                sw.Start(); //開始計時
                if (ChatGPT2IsPrime(i))
                {
                    if (count >= 10 || count == -1)    //初始值 或 10筆後刷新
                    {
                        count = 0;
                        txtShowPrime.Text = $"以下為結果\r\n-----------------\r\n";
                    }
                    else
                    {
                        count++;
                    }
                    Application.DoEvents(); //Event更新
                    txtShowPrime.Text += $"{i} \r 所需時間: {sw.ElapsedMilliseconds.ToString()}秒 \r\n"; //\r count:{count+1} 可看幾筆
                    sw.Stop();  //停止計時(只在發現Prime時)
                    Thread.Sleep(1000);
                }
            }
        }
        private void btnListPrime_Click(object sender, EventArgs e)
        {
            ListPrime();
        }

        /////
        /////
        ///
        /*
         my Ver 失敗
         */
        bool MyNumIsPrime(ulong num)
        {
            if (num == 0 || num == 1)
                return false;
            if (num == 2)
                return true;
            if (num % 2 == 0)
            {
                return false;
            }
            for (ulong i = num - 1; i >= 2; i--)
            {
                if (num % i == 0)
                    return false;
            }
            return true;
        }

        /*
         Google Ver 失敗
        */
        public static bool GoogleIsPrime(ulong n)
        {
            if (n <= 1) return false; // 1 或更小不是質數
            if (n <= 3) return true;  // 2 和 3 是質數

            // 排除偶數和 3 的倍數
            if (n % 2 == 0 || n % 3 == 0) return false;

            // 只需檢查到 sqrt(n)
            // 注意: Math.Sqrt 接受 double，需要轉型
            for (ulong i = 5; i * i <= n; i = i + 6)
            {
                if (n % i == 0 || n % (i + 2) == 0)
                    return false;
            }
            return true;
        }

        /*
        ChatVer 失敗
        */

        static bool ChatGPTIsPrime(ulong n)
        {
            if (n < 2) return false;
            if (n % 2 == 0) return n == 2;

            ulong d = n - 1;
            int s = 0;
            while ((d & 1) == 0)
            {
                d >>= 1;
                s++;
            }

            // deterministic Miller–Rabin bases for 64-bit
            ulong[] bases = { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37 };

            foreach (ulong a in bases)
            {
                if (a >= n) continue;

                ulong x = ModPow(a, d, n);
                if (x == 1 || x == n - 1) continue;

                bool composite = true;
                for (int r = 1; r < s; r++)
                {
                    x = ModMul(x, x, n);
                    if (x == n - 1)
                    {
                        composite = false;
                        break;
                    }
                }
                if (composite) return false;
            }

            return true;
        }

        // 安全乘法，避免 ulong overflow
        static ulong ModMul(ulong a, ulong b, ulong mod)
        {
            ulong result = 0;
            a %= mod;
            while (b > 0)
            {
                if ((b & 1) == 1)
                {
                    result = (result + a) % mod;
                }
                a = (a << 1) % mod;
                b >>= 1;
            }
            return result;
        }

        // 安全次方
        static ulong ModPow(ulong a, ulong exp, ulong mod)
        {
            ulong result = 1;
            a %= mod;
            while (exp > 0)
            {
                if ((exp & 1) == 1)
                {
                    result = ModMul(result, a, mod);
                }
                a = ModMul(a, a, mod);
                exp >>= 1;
            }
            return result;
        }
        /// CPT
        /// 

        /// GPTVer2 唯一可用版
        /// 

        public static bool ChatGPT2IsPrime(BigInteger n, int k = 10)
        {
            if (n < 2) return false;
            if (n == 2 || n == 3) return true;
            if (n % 2 == 0) return false;

            // 將 n-1 拆成 d * 2^s
            BigInteger d = n - 1;
            int s = 0;
            while (d % 2 == 0)
            {
                d /= 2;
                s++;
            }

            Random rng = new Random();

            for (int i = 0; i < k; i++)
            {
                BigInteger a = RandomBigInteger(2, n - 2, rng);
                BigInteger x = BigInteger.ModPow(a, d, n);

                if (x == 1 || x == n - 1)
                    continue;

                bool composite = true;

                for (int r = 1; r < s; r++)
                {
                    x = BigInteger.ModPow(x, 2, n);

                    if (x == n - 1)
                    {
                        composite = false;
                        break;
                    }
                }

                if (composite)
                    return false; // 確定合數
            }

            return true; // 高機率為質數
        }

        // 產生 [min, max] 的隨機 BigInteger
        private static BigInteger RandomBigInteger(BigInteger min, BigInteger max, Random rng)
        {
            byte[] bytes = max.ToByteArray();
            BigInteger result;

            do
            {
                rng.NextBytes(bytes);
                bytes[bytes.Length - 1] &= 0x7F; // 保證正數
                result = new BigInteger(bytes);
            }
            while (result < min || result > max);

            return result;
        }



        /// GPTVer3 失敗
        /// 
        public static bool ChatGPT3IsPrime(ulong n)
        {
            if (n < 2) return false;
            if (n == 2 || n == 3) return true;
            if ((n & 1) == 0) return false; // 偶數

            // 將 n-1 拆成 d * 2^s
            ulong d = n - 1;
            int s = 0;
            while ((d & 1) == 0)
            {
                d >>= 1;
                s++;
            }

            // 固定基數測試，對 ulong 完全足夠
            ulong[] bases = { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37 };

            foreach (var a in bases)
            {
                if (a >= n) break;
                ulong x = ModPow2(a, d, n);
                if (x == 1 || x == n - 1) continue;

                bool composite = true;
                for (int r = 1; r < s; r++)
                {
                    x = ModMul2(x, x, n);
                    if (x == n - 1)
                    {
                        composite = false;
                        break;
                    }
                }
                if (composite) return false;
            }

            return true;
        }

        private static ulong ModPow2(ulong baseVal, ulong exp, ulong mod)
        {
            ulong result = 1;
            baseVal %= mod;

            while (exp > 0)
            {
                if ((exp & 1) == 1)
                    result = ModMul2(result, baseVal, mod);
                baseVal = ModMul2(baseVal, baseVal, mod);
                exp >>= 1;
            }

            return result;
        }

        // 安全乘法，避免 ulong overflow
        private static ulong ModMul2(ulong a, ulong b, ulong mod)
        {
            ulong result = 0;
            a %= mod;
            b %= mod;

            while (b > 0)
            {
                if ((b & 1) == 1)
                {
                    result = (result + a) % mod;
                }
                a = (a << 1) % mod;
                b >>= 1;
            }

            return result;
        }

        /// GPTVer3 進行修改
        /// 
        public static bool ChatGPT3IsPrime_test(BigInteger n)
        {
            if (n < 2) return false;
            if (n == 2 || n == 3) return true;
            if ((n & 1) == 0) return false; // 偶數

            // 將 n-1 拆成 d * 2^s
            BigInteger d = n - 1;
            int s = 0;
            while ((d & 1) == 0)
            {
                d >>= 1;
                s++;
            }

            // 固定基數測試，對 ulong 完全足夠
            BigInteger[] bases = { 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37 };

            foreach (var a in bases)
            {
                if (a >= n) break;
                BigInteger x = ModPow22(a, d, n);
                if (x == 1 || x == n - 1) continue;

                bool composite = true;
                for (int r = 1; r < s; r++)
                {
                    x = ModMul22(x, x, n);
                    if (x == n - 1)
                    {
                        composite = false;
                        break;
                    }
                }
                if (composite) return false;
            }

            return true;
        }

        private static BigInteger ModPow22(BigInteger baseVal, BigInteger exp, BigInteger mod)
        {
            BigInteger result = 1;
            baseVal %= mod;

            while (exp > 0)
            {
                if ((exp & 1) == 1)
                    result = ModMul22(result, baseVal, mod);
                baseVal = ModMul22(baseVal, baseVal, mod);
                exp >>= 1;
            }

            return result;
        }

        // 安全乘法，避免 ulong overflow
        private static BigInteger ModMul22(BigInteger a, BigInteger b, BigInteger mod)
        {
            BigInteger result = 0;
            a %= mod;
            b %= mod;

            while (b > 0)
            {
                if ((b & 1) == 1)
                {
                    result = (result + a) % mod;
                }
                a = (a << 1) % mod;
                b >>= 1;
            }

            return result;
        }

    }
}
